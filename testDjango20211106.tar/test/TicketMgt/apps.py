from django.apps import AppConfig


class TicketmgtConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TicketMgt'
