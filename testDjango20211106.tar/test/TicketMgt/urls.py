from django.urls import path
from . import views

app_name = "TicketMgt"

urlpatterns = [
    # for Ticket Category 
    path('', views.TicketCategoryList.as_view(), name='list'),
    path('create/', views.TicketCategoryCreateView.as_view(), name='create'),
    path('detail/<int:pk>/', views.TicketCategoryDetail.as_view(), name='detail'),
    path('update/<int:pk>/', views.TicketCategoryUpdateView.as_view(), name='update'),
]
