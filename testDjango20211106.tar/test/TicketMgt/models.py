from django.db import models

# Create your models here.

# チケットのカテゴリ（種類）を格納するテーブル
class TicketCategory(models.Model):
    cid       = models.PositiveIntegerField();
    name      = models.CharField(max_length=256)

    def __str__(self):
        return self.name

# チケットのインスタンスを格納するテーブル
class Ticket(models.Model):
   number  = models.PositiveIntegerField()

   def __str__(self):
        return self.name
