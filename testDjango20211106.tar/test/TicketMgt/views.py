from django.shortcuts import render
from django.urls import reverse_lazy
from django.urls import reverse
from django.http import HttpResponse
from django.views.generic import (ListView,CreateView,DetailView,UpdateView)
from . import models

#一覧画面
class TicketCategoryList(ListView):
    #TicketCategoryテーブル連携
    model = models.TicketCategory
    #レコード情報をテンプレートに渡すオブジェクト
    context_object_name = "ticket_category_list"
    #テンプレートファイル連携
    template_name = "TicketCategory_list.html"

class TicketCategoryCreateView(CreateView):
    model = models.TicketCategory
    fields = ("name","cid")
    template_name = "TicketCategory_form.html"
    def get_success_url(self):
        return reverse('TicketMgt:detail',kwargs={'pk':self.object.pk})

class TicketCategoryDetail(DetailView):
    model = models.TicketCategory
    context_object_name = "ticket_category_detail"
    template_name = "TicketCategory_detail.html"

class TicketCategoryUpdateView(UpdateView):
    model = models.TicketCategory
    fields = {"name","cid"}
    template_name = "TicketCategory_form.html"
    def get_success_url(self):
        return reverse('TicketMgt:detail',kwargs={'pk':self.object.pk})
